
### XMPP - core (chrome packaged app)


load it as unpacked extension into your chromium/chrome.
