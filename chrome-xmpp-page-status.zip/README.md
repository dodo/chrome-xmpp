
### XMPP - page action (chrome extension)

load it as unpacked extension into your chromium/chrome.
