
### XMPP - gears (chrome extension)

load it as unpacked extension into your chromium/chrome.
