
### XMPP - gears (chrome extension)

load it as unpacked extension into your chromium/chrome.

TODO
show client settings only enabled when all clients are offline
https://developer.chrome.com/extensions/webstore to install packaged app
https://developer.chrome.com/extensions/permissions to ask for webstore when user clicks on 'install background app'
<!-- https://developer.chrome.com/extensions/pageAction to show icon in the url bar to show that a site is using xmpp and to be able to disconnect it without disconnecting the account if other tabs are connected -->
